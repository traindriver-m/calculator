public class Rome {
    String words[]; //объявляю переменную words
    String rimskie[];//объявляю переменную rimskie
    String str;//объявляю переменную str
    char deystvie;//объявляю переменную deystvie
    int x;//объявляю переменную x
    int y;//объявляю переменную y

    public void romme() {
        String[] fullRome = new String[]{"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII", "XIII", "XIV", "XV",
                "XVI", "XVII", "XVIII", "XIX", "XX", "XXI", "XXII", "XXIII", "XXIV", "XXV", "XXVI", "XXVII", "XXVIII", "XXIX", "XXX", "XXXI", "XXXII", "XXXIII", "XXXIV",
                "XXXV", "XXXVI", "XXXVII", "XXXVIII", "XXXIX", "XL", "XLI", "XLII", "XLIII", "XLIV", "XLV", "XLVI", "XLVII", "XLVIII", "XLIX", "L", "LI", "LII", "LIII",
                "LIV", "LV", "lVI", "LVII", "LVIII", "LIX", "LX", "LXI", "LXII", "LXIII", "LXIV", "LXV", "LXVI", "LXVII", "LXVIII", "LXIX", "LXX", "LXXI", "LXXII",
                "LXXIII", "LXXIV", "LXXV", "LXXVI", "LXXVII", "LXXVIII", "LXXIX", "LXXX", "LXXXI", "LXXXII", "LXXXIII", "LXXXIV", "LXXXV", "LXXXVI", "LXXXVII",
                "LXXXVIII", "LXXXIX", "XC", "XCI", "XCII", "XCIII", "XCIV", "XCV", "XCVI", "XCVII", "XCVIII", "XCIX", "C"}; // создаю массив римсиих цифр от 1 до 100

        if ("I".equals(words[0])) x = 1; // присваиваю числовое значение первому введенному римскому числу
        if ("II".equals(words[0])) x = 2; // -"-
        if ("III".equals(words[0])) x = 3;// -"-
        if ("IV".equals(words[0])) x = 4;// -"-
        if ("V".equals(words[0])) x = 5;// -"-
        if ("V".equals(words[0])) x = 5;// -"-
        if ("VI".equals(words[0])) x = 6;// -"-
        if ("VII".equals(words[0])) x = 7;// -"-
        if ("VIII".equals(words[0])) x = 8;// -"-
        if ("IX".equals(words[0])) x = 9;// -"-
        if ("X".equals(words[0])) x = 10;// -"-
        if ("I".equals(words[1])) y = 1;// присваиваю числовое значение второму введенному римскому числу
        if ("II".equals(words[1])) y = 2;// -"-
        if ("III".equals(words[1])) y = 3;// -"-
        if ("IV".equals(words[1])) y = 4;// -"-
        if ("V".equals(words[1])) y = 5;// -"-
        if ("VI".equals(words[1])) y = 6;// -"-
        if ("VII".equals(words[1])) y = 7;// -"-
        if ("VIII".equals(words[1])) y = 8;// -"-
        if ("IX".equals(words[1])) y = 9;// -"-
        if ("X".equals(words[1])) y = 10;// -"-


        if (x < 11 & y < 11 & x > 0 & y > 0) { //задается условие ограничивающие диапазон вводимых числел от 0  до 10
            int otvet1; // объявляю переменную otvet1
            switch (deystvie) { // приемняю оператор выбора который сравнивает значение переменной  deystvie1 (которое получено ранее) со значениями в блоках case
                case '+': // если выбран + то выполняются 2 строчки ниже
                    otvet1 = x + y;
                    break;
                case '-': // если выбран - то выполняются 2 строчки ниже
                    otvet1 = x - y;
                    break; // управление передается за пределы switch
                case '*': // если выбран * то выполняются 2 строчки ниже
                    otvet1 = x * y;
                    break; // управление передается за пределы switch
                case '/': // если выбран / то выполняются 2 строчки ниже
                    otvet1 = x / y;
                    break; // управление передается за пределы switch

                default:
                    throw new IllegalStateException("Unexpected value: " + deystvie);// по идее должно бы быть исключение при неверно введенном знаке.но выскаиевает другое

            }
            System.out.println("ответ = " + fullRome[otvet1 - 1]); // вывод ответа

        } else{
            throw new IllegalStateException("Что за дичь введена?"); //выдает исключение при неверно введенных числах

        }
    }
}


